/**
 * BigFix Lifecycle Training App
 * Implements interactive modules, state tracking, quizzes, and Google Form loading.
 */

// Configuration Settings
const CONFIG = {
    // To receive submissions directly to your Gmail on the form itself:
    // 1. Visit https://web3forms.com/ and enter your Gmail to get a free Access Key.
    // 2. Paste your Access Key below.
    web3formsAccessKey: "YOUR_ACCESS_KEY_HERE",

    // (Optional Fallback) Replace this email address with your actual email address.
    targetEmail: "your-email@example.com"
};


// Module Data: Contains text tutorials, code snippets, and quizzes.
const modulesData = [
    {
        id: 1,
        number: "Module 01",
        title: "BigFix Architecture & Agent Operations",
        tag: "Core Infrastructure",
        time: "15 Mins",
        content: `
            <div class="content-section">
                <h4>1. BigFix Distributed Loop Architecture</h4>
                <p>Unlike traditional client-server systems that poll at scheduled times, HCL BigFix uses a patented <strong>distributed loop architecture</strong>. The BigFix Agent constantly evaluates its local system state against active "Fixlets" and reports changes upstream. This allows a single BigFix Server to support over 250,000 endpoints with minimal bandwidth overhead.</p>
                <div class="callout info">
                    <div class="callout-title">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                        Architecture Core Components
                    </div>
                    <div class="callout-content">
                        <ul>
                            <li><strong>Root Server:</strong> The central management hub coordinating content, database writes, and action distribution.</li>
                            <li><strong>Relays:</strong> Intermediary servers acting as distribution points. Endpoints connect to Relays, reducing WAN utilization from 100% to less than 1%.</li>
                            <li><strong>Client (Agent):</strong> A lightweight service running on endpoints that autonomously evaluates Relevance expressions.</li>
                            <li><strong>Console:</strong> The operator interface used to author relevance, configure tasks, and monitor deployments.</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="content-section">
                <h4>2. The Agent Heartbeat and Port 52311</h4>
                <p>The BigFix Agent listens on UDP Port <strong>52311</strong> for notifications of new content. If UDP is blocked, the agent falls back to gathering new content on a periodic poll interval (default is 24 hours, but can be configured down to minutes). All communication is initiated outbound by the client or relay via TCP 52311 to secure infrastructure.</p>
                <div class="code-block-header">Client Configuration (Linux: besclient.config)</div>
                <pre><code>[Software\\BigFix\\EnterpriseClient\\Settings\\Client]
_BESClient_Comm_UDPMustBeUsed = 1
_BESClient_Comm_CommandPollEnable = 1
_BESClient_Comm_CommandPollIntervalSeconds = 3600
_BESClient_RelaySelect_FailoverRelayList = http://failover-relay.domain.com:52311/bfmirror/downloads/</code></pre>
            </div>
        `,
        quiz: {
            question: "What default port does the BigFix Client use to communicate with Relays and Servers?",
            options: [
                "TCP/UDP Port 8080",
                "TCP/UDP Port 52311",
                "TCP Port 443 only",
                "UDP Port 1433"
            ],
            correctIndex: 1,
            explanation: "TCP/UDP Port 52311 is the default port utilized by HCL BigFix for communications between clients, relays, and servers. Incoming UDP notifications awaken the agent, and TCP is used for gathering site content and posting report archives."
        }
    },
    {
        id: 2,
        number: "Module 02",
        title: "Patch Management & Action Sites",
        tag: "Remediation",
        time: "20 Mins",
        content: `
            <div class="content-section">
                <h4>1. Understanding Fixlets vs. Tasks</h4>
                <p>In BigFix, there is a distinct difference between Fixlets and Tasks, although both contain action scripts and relevance:</p>
                <ul>
                    <li><strong>Fixlets:</strong> Used for vulnerability remediation. A Fixlet has Relevance that evaluates to <strong>true</strong> when the system is vulnerable, and automatically evaluates to <strong>false</strong> after the patch is applied. The Action is marked as "Fixed" only when relevance resolves to false.</li>
                    <li><strong>Tasks:</strong> Used for configuration changes, maintenance, or software distribution. Relevance evaluates to true to target endpoints, but the action does not necessarily change the system in a way that makes relevance false. Success is measured by the execution of the action script.</li>
                </ul>
            </div>

            <div class="content-section">
                <h4>2. Action Sites and Content Propagation</h4>
                <p>BigFix distributes content through <strong>Action Sites</strong>. The Root server gathers patch content from HCL Global Servers, signs the digital manifests, and propagates them down the relay tree. Endpoints receive metadata lists, evaluate local applicability, and download actual installer files from their parent Relays.</p>
                <div class="callout">
                    <div class="callout-title">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                        What is a Baseline?
                    </div>
                    <div class="callout-content">
                        A Baseline is a collection of multiple Fixlets/Tasks ordered sequentially. When deployed, the client compiles them into a single Action. If one patch fails, the client proceeds according to baseline settings (e.g. continue on failure). Baselines dramatically simplify complex update schedules like Patch Tuesday.
                    </div>
                </div>
                <div class="code-block-header">Applicability Relevance Example (Checking for Windows Update KB)</div>
                <pre><code>(name of it = "Win10" or name of it = "Win11") of operating system 
and not exists quick_fix_engineering "KB5012643"</code></pre>
            </div>
        `,
        quiz: {
            question: "What is the primary operational difference between a Fixlet and a Task in BigFix?",
            options: [
                "Fixlets only run on Server OS editions, while Tasks run on Desktop OS.",
                "Fixlet actions are only marked successful when their applicability relevance evaluates to false post-execution; Tasks do not rely on applicability relevance becoming false.",
                "Tasks can be grouped into baselines, whereas Fixlets cannot.",
                "Tasks execute immediately; Fixlets require a client reboot before running."
            ],
            correctIndex: 1,
            explanation: "Fixlets check for remediation: their success depends on the applicability relevance becoming false after deployment. Tasks perform commands whose success is measured by script execution results, since their applicability might remain true."
        }
    },
    {
        id: 3,
        number: "Module 03",
        title: "Software Distribution Dashboards",
        tag: "Application Delivery",
        time: "15 Mins",
        content: `
            <div class="content-section">
                <h4>1. The Software Distribution Lifecycle</h4>
                <p>HCL BigFix Lifecycle includes a dedicated Software Distribution dashboard. This streamlines the packaging of complex applications (.msi, .exe, .dmg, .pkg, or scripts) and pushes them to target computers. The server automatically generates relevance conditions and packages packages into compressed archives (.tmp) uploaded to the Root Server storage.</p>
            </div>

            <div class="content-section">
                <h4>2. Download Pre-Caching & Prefetching</h4>
                <p>To avoid WAN saturation, BigFix utilizes a <strong>prefetching mechanism</strong>. Before an application installer runs, the Root Server downloads it, calculates its SHA-256 hash and file size, and registers it. When deployed, relays retrieve the file beforehand and endpoints gather it locally. The client validates the file hash against the relevance specifications before launching the installer.</p>
                <div class="code-block-header">Prefetch Command Format (ActionScript)</div>
                <pre><code>// Prefetch command secures payload delivery
prefetch setup.msi sha1:713d7e5fae06c7478d10b77b1029c78d193ea084 size:12450320 http://bes-server.corp:52311/Uploads/713d7e5fae06c7478d10b77b1029c78d193ea084/setup.msi.tmp sha256:a6ef77cc57bc4882dfba8821f576e271a3cf8d4dfb93dae0c90c9b0e1aefd5ea

// Run silent installer
waithidden msiexec.exe /i __Download\\setup.msi /qn /norestart</code></pre>
                <div class="callout info">
                    <div class="callout-title">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                        What is waithidden?
                    </div>
                    <div class="callout-content">
                        The <code>waithidden</code> command runs the installer command in a hidden window, pausing ActionScript execution until the installer completes (returning an exit code). Use <code>/qn</code> (silent) switches to prevent interactive prompts on target endpoint screens.
                    </div>
                </div>
            </div>
        `,
        quiz: {
            question: "Why does the ActionScript use prefetch blocks with SHA hashes instead of a direct download URL?",
            options: [
                "To compress the file for faster transport.",
                "To encrypt the file payload so users cannot open it manually.",
                "To verify the exact file size and cryptographic signature before executing, preventing execution of corrupted or intercepted payloads.",
                "To hide the download path from BigFix Relays."
            ],
            correctIndex: 2,
            explanation: "Prefetch commands verify the integrity and security of the payload using size, SHA-1, and SHA-256 hashes. If the downloaded file does not match the hash, the client refuses to execute it, shielding endpoints from tampered software installers."
        }
    },
    {
        id: 4,
        number: "Module 04",
        title: "OS Deployment (OSD) & Provisioning",
        tag: "Bare Metal & Migrations",
        time: "25 Mins",
        content: `
            <div class="content-section">
                <h4>1. BigFix Bare Metal Provisioning</h4>
                <p>BigFix OS Deployment (OSD) provides a unified infrastructure to capture and deploy operating systems. By combining DHCP, PXE (Preboot Execution Environment), and TFTP servers on localized Relays, OSD can take a brand-new machine out of the box and automatically provision Windows or Linux profiles over the local network.</p>
            </div>

            <div class="content-section">
                <h4>2. The Deployment Workflow</h4>
                <p>The OSD process progresses through structured phases:</p>
                <ol>
                    <li><strong>Capture:</strong> Capture custom, reference OS images as standard WIM (Windows) or IMG (Linux) files.</li>
                    <li><strong>Upload drivers:</strong> Import hardware-specific network, storage, and chipset drivers into the driver library repository.</li>
                    <li><strong>Binding:</strong> The OSD dashboard matches hardware PCI Vendor IDs of target devices with drivers in the repository.</li>
                    <li><strong>Deployment Task:</strong> Target endpoints are assigned OSD tasks, boot via PXE, pull the WinPE/boot image, and apply the customized OS configuration.</li>
                </ol>
                <div class="callout info">
                    <div class="callout-title">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                        PXE Server Location
                    </div>
                    <div class="callout-content">
                        OSD allows installing the network boot (PXE) components directly onto local BigFix Relays. This enables remote sites to deploy local OS images without sending massive Giga-byte files across slow wide area network (WAN) links.
                    </div>
                </div>
            </div>
        `,
        quiz: {
            question: "Which components must be enabled on a BigFix Relay to support bare-metal system imaging over local subnets?",
            options: [
                "Active Directory and SQL Server Express",
                "PXE Network Boot Service (DHCP/TFTP services) and the OSD Bare Metal Server package",
                "WebUI and BES Root Server service",
                "FTP server and WebReports"
            ],
            correctIndex: 1,
            explanation: "To boot bare-metal machines, the local Relay must run PXE Network Boot services (DHCP/TFTP protocols) and the OSD Bare Metal Server components to feed boot images (WinPE/Linux equivalent) and apply driver bindings."
        }
    },
    {
        id: 5,
        number: "Module 05",
        title: "Server Automation & Relevance Language",
        tag: "Orchestration & Syntax",
        time: "30 Mins",
        content: `
            <div class="content-section">
                <h4>1. Introduction to Relevance Language</h4>
                <p>Relevance is a query language executed locally by the BigFix Client to query hardware, software, files, registry settings, and system configurations. Relevance is designed to be read-only and fast. It prevents client machines from running scripts if they do not meet prerequisites.</p>
                <div class="code-block-header">Relevance Inspector Logic Examples</div>
                <pre><code>// 1. Check if client is running Windows OS
name of operating system contains "Win"

// 2. Check if a specific file exists and matches versions
exists file "C:\\Program Files\\App\\bin.dll" whose (version of it >= "4.2.1")

// 3. Find list of IP addresses
addresses of ip interfaces of network</code></pre>
            </div>

            <div class="content-section">
                <h4>2. ActionScript & Server Automation</h4>
                <p>While Relevance is read-only, **ActionScript** is the command language used to modify endpoints. Additionally, **Server Automation** allows you to sequence multiple Fixlet and ActionScript steps across multiple servers. For example, you can sequence database server updates, pause for validation, and only then proceed to update application servers.</p>
                <div class="code-block-header">ActionScript Commands</div>
                <pre><code>// Set a registry key
regset "[HKEY_LOCAL_MACHINE\\Software\\MySettings]" "Updated"="True"

// Delete temp file
delete "C:\\temp\\installer.msi"

// Run external command and wait
wait cmd.exe /c "echo System patched > C:\\patched.log"</code></pre>
            </div>
        `,
        quiz: {
            question: "Which Relevance expression correctly searches a Windows system for a file located at 'C:\\App\\config.ini' whose configuration version is less than 5?",
            options: [
                "exists C:\\App\\config.ini whose (version < 5)",
                "exists file 'C:\\App\\config.ini' whose (version of it < '5')",
                "if exists file 'C:\\App\\config.ini' then version of file < 5 else false",
                "exists file \"C:\\App\\config.ini\" whose (version of it < 5)"
            ],
            correctIndex: 3,
            explanation: "Option 4 uses correct Relevance syntax: 'exists file \"path\"' targets the object, and 'whose (version of it < 5)' evaluates the property. In Relevance, string literals in filters should use double quotes, and integers can be compared directly."
        }
    },
    {
        id: 6,
        number: "Module 06",
        title: "BigFix WebUI & Real-Time Query",
        tag: "Web Operations & Querying",
        time: "20 Mins",
        content: `
            <div class="content-section">
                <h4>1. BigFix WebUI Architecture</h4>
                <p>The <strong>BigFix WebUI</strong> provides a lightweight, responsive web console for day-to-day operations. Unlike the heavy windows-native Console, the WebUI is app-centric (Patch, Software, Query, etc.) and runs as a self-contained node service. It can be installed directly on the Root Server or delegated to a standalone WebUI Server to minimize load.</p>
                <div class="callout info">
                    <div class="callout-title">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                        Role-Based Access Control (RBAC)
                    </div>
                    <div class="callout-content">
                        WebUI applications leverage BigFix's granular operator permissions. Administrators can allocate specific roles (e.g., "Patch Operator") to restrict users to designated sites and devices while locking down access to sensitive features like Software Distribution or direct script execution.
                    </div>
                </div>
            </div>

            <div class="content-section">
                <h4>2. Real-Time Query Mechanics</h4>
                <p>Traditional BigFix relevance evaluation relies on clients reporting changes periodically. <strong>BigFix Query</strong> changes this by establishing a persistent fast-channel TCP connection between clients and relays. When a WebUI operator executes a query, the command is broadcast instantly, evaluated in-memory by the client, and returned in seconds without writing to the database.</p>
                <div class="code-block-header">WebUI Config (Windows Server Registry)</div>
                <pre><code>[HKEY_LOCAL_MACHINE\\SOFTWARE\\BigFix\\Enterprise Server\\WebUI]
"WebUIServicePort"=dword:00001f90
"EnableQueryChannel"=dword:00000001
"QueryTimeoutSeconds"=dword:000000b4</code></pre>
            </div>
        `,
        quiz: {
            question: "How does BigFix Query achieve near real-time results from endpoints compared to traditional Fixlet applicability reporting?",
            options: [
                "It establishes a direct SSH/WinRM remote shell tunnel to execute PowerShell or Bash scripts on target endpoints.",
                "It forces client systems to perform a quick reboot to refresh their local inventory cache.",
                "It leverages a persistent fast-channel TCP connection down the relay hierarchy to deliver queries that the client evaluates in-memory and returns instantly.",
                "It mounts a shared network folder on each client to scan files directly."
            ],
            correctIndex: 2,
            explanation: "BigFix Query routes queries down the relay hierarchy using a persistent fast-channel TCP protocol. Clients receive the query, evaluate the relevance expression in-memory, and return results immediately, bypassing the slower standard client logging and database reporting pipeline."
        }
    },
    {
        id: 7,
        number: "Module 07",
        title: "REST API & Session Relevance",
        tag: "Integration & API Automation",
        time: "25 Mins",
        content: `
            <div class="content-section">
                <h4>1. BigFix REST API Integration</h4>
                <p>The BigFix REST API allows developers to automate tasks, import content, and integrate BigFix with third-party tools (like ServiceNow or Ansible). Operating over HTTPS on port <strong>52311</strong>, the REST API supports standard HTTP methods (GET, POST, PUT, DELETE) and utilizes XML/JSON schemas for payload serialization.</p>
            </div>

            <div class="content-section">
                <h4>2. Session Relevance vs. Client Relevance</h4>
                <p>It is vital to understand the difference between the two relevance environments:</p>
                <ul>
                    <li><strong>Client Relevance:</strong> Evaluated locally by the agent on individual endpoints. It can access local system resources (e.g. <code>files</code>, <code>registry keys</code>, <code>services</code>).</li>
                    <li><strong>Session Relevance:</strong> Evaluated by the Root Server or WebReports database. It is used to query aggregated data about the entire infrastructure (e.g., "how many Windows endpoints are missing critical patches?"). Session Relevance is extremely fast because it leverages the console memory cache and database indexing.</li>
                </ul>
                <div class="code-block-header">Python REST API Query (Session Relevance Request)</div>
                <pre><code>import requests

url = "https://bes-server.domain.com:52311/api/query"
params = {"relevance": "(name of it, operating system of it) of bes computers"}
auth = ("api_user", "secure_password")

response = requests.get(url, params=params, auth=auth, verify=False)
print(response.text)</code></pre>
            </div>
        `,
        quiz: {
            question: "What is the key functional difference between Client Relevance and Session Relevance?",
            options: [
                "Client Relevance is written in ActionScript, whereas Session Relevance is written in pure SQL.",
                "Client Relevance executes locally on endpoints to evaluate system state; Session Relevance executes on the Root Server/WebReports server to query aggregated data across all endpoints.",
                "Session Relevance can write and modify files on endpoints, while Client Relevance is read-only.",
                "Client Relevance works on Windows only, while Session Relevance works on Unix Relays only."
            ],
            correctIndex: 1,
            explanation: "Client Relevance is evaluated by the local BigFix Agent to determine applicability on that specific system. Session Relevance is evaluated by the Root Server or WebReports server to query the global database and aggregate information about the entire deployment."
        }
    }
];

// App State Management
let state = {
    completedModules: [],
    quizScores: {},
    currentModuleId: 1
};

// DOM Cache
const header = document.getElementById("header");
const progressFill = document.getElementById("progressFill");
const progressPercent = document.getElementById("progressPercent");
const modulesGrid = document.getElementById("modulesGrid");
const modalOverlay = document.getElementById("modalOverlay");
const modalCloseBtn = document.getElementById("modalCloseBtn");
const modalTag = document.getElementById("modalTag");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");
const modalPrevBtn = document.getElementById("modalPrevBtn");
const modalNextBtn = document.getElementById("modalNextBtn");
const markCompleteBtn = document.getElementById("markCompleteBtn");
const loadFormBtn = document.getElementById("loadFormBtn");
const formPlaceholder = document.getElementById("formPlaceholder");
const googleFormIframe = document.getElementById("googleFormIframe");

// Initialize application
function init() {
    loadState();
    renderModules();
    updateOverallProgress();
    setupEventListeners();
}

// Load state from local storage
function loadState() {
    const savedState = localStorage.getItem("bigfix_training_state");
    if (savedState) {
        try {
            state = JSON.parse(savedState);
            // Ensure properties exist
            if (!state.completedModules) state.completedModules = [];
            if (!state.quizScores) state.quizScores = {};
            if (!state.currentModuleId) state.currentModuleId = 1;
        } catch (e) {
            console.error("Error reading saved state: ", e);
        }
    }
}

// Save state to local storage
function saveState() {
    localStorage.setItem("bigfix_training_state", JSON.stringify(state));
}

// Render the module grid cards dynamically (synchronizing fallback cards)
function renderModules() {
    const cards = document.querySelectorAll(".module-card");
    cards.forEach(card => {
        const moduleId = parseInt(card.getAttribute("data-module-id"));
        const data = modulesData.find(m => m.id === moduleId);

        if (data) {
            // Check status
            const isCompleted = state.completedModules.includes(moduleId);
            const badge = card.querySelector(".module-status-badge");
            const quizState = card.querySelector(".quiz-state-info");

            if (isCompleted) {
                card.classList.add("completed");
                card.classList.remove("active");
                if (badge) badge.textContent = "Completed";
            } else {
                card.classList.remove("completed");
                // Set first incomplete as active
                const isFirstIncomplete = state.completedModules.length === 0 ? moduleId === 1 :
                    (Math.min(...modulesData.map(m => m.id).filter(id => !state.completedModules.includes(id))) === moduleId);

                if (isFirstIncomplete) {
                    card.classList.add("active");
                    if (badge) badge.textContent = "Active";
                } else {
                    card.classList.remove("active");
                    if (badge) badge.textContent = "Not Started";
                }
            }

            // Update quiz status
            const score = state.quizScores[moduleId];
            if (quizState) {
                if (score !== undefined) {
                    quizState.textContent = `Quiz: Passed (${score}%)`;
                    quizState.style.color = "var(--success)";
                } else {
                    quizState.textContent = "Quiz: Incomplete";
                    quizState.style.color = "var(--text-muted)";
                }
            }
        }
    });
}

// Update the global progress metrics in the UI
function updateOverallProgress() {
    const totalModules = modulesData.length;
    const completedCount = state.completedModules.length;
    const percentage = totalModules > 0 ? Math.round((completedCount / totalModules) * 100) : 0;

    if (progressFill) progressFill.style.width = `${percentage}%`;
    if (progressPercent) progressPercent.textContent = `${percentage}%`;

    // Update stats counters
    const countElement = document.getElementById("statModulesCount");
    if (countElement) {
        countElement.textContent = `${completedCount}/${totalModules}`;
    }

    // Update quiz count dynamically in stats bar
    const statQuizzesCount = document.getElementById("statQuizzesCount");
    if (statQuizzesCount) {
        statQuizzesCount.textContent = totalModules;
    }

    // Update registration progress field
    const regProgress = document.getElementById("regProgress");
    if (regProgress) {
        regProgress.value = `${percentage}% Completed (${completedCount}/${totalModules} Modules)`;
    }
}

// Set up UI Event Listeners
function setupEventListeners() {
    // Scroll header effect
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            header.classList.add("scrolled");
        } else {
            header.classList.remove("scrolled");
        }

        // Simple scrollspy active state updates
        const sections = ["hero", "modules", "registration"];
        let currentSection = "hero";

        sections.forEach(secId => {
            const el = document.getElementById(secId);
            if (el) {
                const rect = el.getBoundingClientRect();
                if (rect.top <= 120 && rect.bottom >= 120) {
                    currentSection = secId;
                }
            }
        });

        document.querySelectorAll(".nav-links a").forEach(a => {
            a.classList.remove("active");
            if (a.getAttribute("href") === `#${currentSection}`) {
                a.classList.add("active");
            }
        });
    });

    // Module Card Click
    const cards = document.querySelectorAll(".module-card");
    cards.forEach(card => {
        card.addEventListener("click", () => {
            const moduleId = parseInt(card.getAttribute("data-module-id"));
            openModuleModal(moduleId);
        });
    });

    // Close Modal Events
    if (modalCloseBtn) modalCloseBtn.addEventListener("click", closeModal);
    if (modalOverlay) {
        modalOverlay.addEventListener("click", (e) => {
            if (e.target === modalOverlay) closeModal();
        });
    }

    // Modal navigation
    if (modalPrevBtn) {
        modalPrevBtn.addEventListener("click", () => {
            const prevId = state.currentModuleId - 1;
            if (prevId >= 1) openModuleModal(prevId);
        });
    }
    if (modalNextBtn) {
        modalNextBtn.addEventListener("click", () => {
            const nextId = state.currentModuleId + 1;
            if (nextId <= modulesData.length) openModuleModal(nextId);
        });
    }

    // Mark completed toggle
    if (markCompleteBtn) {
        markCompleteBtn.addEventListener("click", () => {
            toggleModuleCompletion(state.currentModuleId);
        });
    }

    // Google Form Load Button Trigger
    if (loadFormBtn) {
        loadFormBtn.addEventListener("click", loadGoogleForm);
    }

    // Toggle Tabs Logic
    const tabEmailForm = document.getElementById("tabEmailForm");
    const tabGoogleForm = document.getElementById("tabGoogleForm");
    const emailForm = document.getElementById("emailForm");
    const googleFormContainer = document.getElementById("googleFormContainer");

    if (tabEmailForm && tabGoogleForm && emailForm && googleFormContainer) {
        tabEmailForm.addEventListener("click", () => {
            tabEmailForm.classList.add("active");
            tabGoogleForm.classList.remove("active");
            emailForm.classList.remove("hidden");
            googleFormContainer.classList.add("hidden");
        });

        tabGoogleForm.addEventListener("click", () => {
            tabGoogleForm.classList.add("active");
            tabEmailForm.classList.remove("active");
            googleFormContainer.classList.remove("hidden");
            emailForm.classList.add("hidden");
        });
    }

    // Email Form Submit Logic
    if (emailForm) {
        emailForm.addEventListener("submit", handleEmailFormSubmit);
    }
}

// Open module detail view modal
function openModuleModal(moduleId) {
    state.currentModuleId = moduleId;
    saveState();

    const mod = modulesData.find(m => m.id === moduleId);
    if (!mod) return;

    // Set text headers
    if (modalTag) modalTag.textContent = mod.number;
    if (modalTitle) modalTitle.textContent = mod.title;

    // Build training page body + quiz container
    const isCompleted = state.completedModules.includes(moduleId);
    const markBtnText = isCompleted ? "Reset Progress" : "Mark Completed";
    if (markCompleteBtn) {
        markCompleteBtn.textContent = markBtnText;
        if (isCompleted) {
            markCompleteBtn.classList.remove("btn-secondary");
            markCompleteBtn.classList.add("btn-primary");
        } else {
            markCompleteBtn.classList.remove("btn-primary");
            markCompleteBtn.classList.add("btn-secondary");
        }
    }

    // Render Modal Content
    let bodyHtml = mod.content;

    // Append Quiz template html
    const hasQuizScore = state.quizScores[moduleId] !== undefined;
    bodyHtml += `
        <div class="quiz-container" id="quizContainer-${moduleId}">
            <h4>
                <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-1.125-.504-1.125-1.125-1.125H9.75M3 16.5V19.5c0 .621.504 1.125 1.125 1.125h15.75c.621 0 1.125-.504 1.125-1.125V16.5M3 16.5h18M3 16.5v-3.75C3 11.621 3.504 11.125 4.125 11.125h15.75c.621 0 1.125.504 1.125 1.125V16.5M3 7.5V4.5c0-.621.504-1.125 1.125-1.125h15.75c.621 0 1.125.504 1.125 1.125V7.5M3 7.5h18M3 7.5v3.75c0 .621.504 1.125 4.125 1.125h15.75c.621 0 1.125-.504 1.125-1.125V7.5"/></svg>
                Knowledge Assessment
            </h4>
            <p class="quiz-question">${mod.quiz.question}</p>
            <div class="quiz-options">
                ${mod.quiz.options.map((opt, index) => {
        const optionId = `opt-${moduleId}-${index}`;
        const disabledStr = hasQuizScore ? 'disabled' : '';
        const checkedStr = (hasQuizScore && mod.quiz.correctIndex === index) ? 'checked' : '';
        const correctClass = (hasQuizScore && mod.quiz.correctIndex === index) ? 'correct' : '';
        return `
                        <label class="quiz-option ${correctClass}" for="${optionId}">
                            <input type="radio" name="quiz-radio-${moduleId}" id="${optionId}" value="${index}" ${disabledStr} ${checkedStr}>
                            <span>${opt}</span>
                        </label>
                    `;
    }).join('')}
            </div>
            ${!hasQuizScore ? `<button class="btn btn-primary" onclick="submitQuiz(${moduleId})">Submit Answer</button>` : ''}
            <div class="quiz-feedback ${hasQuizScore ? 'show success-feedback' : ''}" id="quizFeedback-${moduleId}">
                ${hasQuizScore ? `<strong>Passed!</strong> Score: 100%. <br>${mod.quiz.explanation}` : ''}
            </div>
        </div>
    `;

    if (modalBody) modalBody.innerHTML = bodyHtml;

    // Configure Next/Prev Buttons
    if (modalPrevBtn) {
        if (moduleId === 1) {
            modalPrevBtn.style.visibility = "hidden";
        } else {
            modalPrevBtn.style.visibility = "visible";
        }
    }

    if (modalNextBtn) {
        if (moduleId === modulesData.length) {
            modalNextBtn.style.visibility = "hidden";
        } else {
            modalNextBtn.style.visibility = "visible";
        }
    }

    // Add event listeners on options to style selection border
    setTimeout(() => {
        const optionLabels = document.querySelectorAll(`#quizContainer-${moduleId} .quiz-option`);
        optionLabels.forEach(lbl => {
            const rad = lbl.querySelector('input[type="radio"]');
            if (rad && !rad.disabled) {
                lbl.addEventListener('click', () => {
                    optionLabels.forEach(l => l.classList.remove('selected'));
                    lbl.classList.add('selected');
                });
            }
        });
    }, 50);

    // Open Modal
    if (modalOverlay) modalOverlay.classList.add("open");
    document.body.style.overflow = "hidden"; // Prevent background scroll
}

// Close Modal
function closeModal() {
    if (modalOverlay) modalOverlay.classList.remove("open");
    document.body.style.overflow = ""; // Enable scroll
}

// Submit Module Quiz Answers
window.submitQuiz = function (moduleId) {
    const mod = modulesData.find(m => m.id === moduleId);
    if (!mod) return;

    const selectedRadio = document.querySelector(`input[name="quiz-radio-${moduleId}"]:checked`);
    if (!selectedRadio) {
        alert("Please select an answer option first!");
        return;
    }

    const userIndex = parseInt(selectedRadio.value);
    const correctIndex = mod.quiz.correctIndex;
    const container = document.getElementById(`quizContainer-${moduleId}`);
    const feedback = document.getElementById(`quizFeedback-${moduleId}`);
    const optionLabels = container.querySelectorAll('.quiz-option');

    // Disable inputs
    container.querySelectorAll('input[type="radio"]').forEach(rad => rad.disabled = true);

    // Remove the submit button
    const submitBtn = container.querySelector('button');
    if (submitBtn) submitBtn.remove();

    // Render visual outcomes
    optionLabels.forEach((label, idx) => {
        label.classList.remove('selected');
        if (idx === correctIndex) {
            label.classList.add('correct');
        } else if (idx === userIndex) {
            label.classList.add('incorrect');
        }
    });

    if (userIndex === correctIndex) {
        // Success
        feedback.className = "quiz-feedback show success-feedback";
        feedback.innerHTML = `<strong>Correct!</strong> Well done. <br>${mod.quiz.explanation}`;
        state.quizScores[moduleId] = 100;

        // Auto-complete module on correct quiz submission
        if (!state.completedModules.includes(moduleId)) {
            state.completedModules.push(moduleId);
        }
    } else {
        // Incorrect
        feedback.className = "quiz-feedback show error-feedback";
        feedback.innerHTML = `<strong>Incorrect.</strong> The correct answer is: <em>${mod.quiz.options[correctIndex]}</em>. <br><br><strong>Rationale:</strong> ${mod.quiz.explanation}`;
        state.quizScores[moduleId] = 0; // Fail

        // Still register completed modules, but you scored 0 on quiz
        if (!state.completedModules.includes(moduleId)) {
            state.completedModules.push(moduleId);
        }
    }

    // Save state & redraw
    saveState();
    renderModules();
    updateOverallProgress();

    // Update close button in modal view
    const isCompleted = state.completedModules.includes(moduleId);
    if (markCompleteBtn) {
        markCompleteBtn.textContent = isCompleted ? "Reset Progress" : "Mark Completed";
        if (isCompleted) {
            markCompleteBtn.classList.remove("btn-secondary");
            markCompleteBtn.classList.add("btn-primary");
        }
    }
};

// Toggle Completion of Modules manually
function toggleModuleCompletion(moduleId) {
    const index = state.completedModules.indexOf(moduleId);
    if (index > -1) {
        // Reset progress
        state.completedModules.splice(index, 1);
        delete state.quizScores[moduleId];
    } else {
        // Complete
        state.completedModules.push(moduleId);
        // Default quiz score to 100 on forced complete
        state.quizScores[moduleId] = 100;
    }

    saveState();
    renderModules();
    updateOverallProgress();

    // Refresh modal contents (to reset/update the quiz state visual layout)
    openModuleModal(moduleId);
}

// Lazy load Google Form
function loadGoogleForm() {
    if (formPlaceholder && googleFormIframe) {
        // Transition animation: Fade out placeholder
        formPlaceholder.classList.add("hidden");

        // Load actual form.
        // We use a beautiful standard public Google Forms template (a contact feedback template) 
        // to demonstrate the integration out-of-the-box.
        googleFormIframe.src = "https://docs.google.com/forms/d/e/1FAIpQLSeyIfQTuWdZnL2Or6nzLR3h8lBmsc-Kv4bQk_DCRN0sa5LcPw/viewform?usp=publish-editor";
    }
}

// Handle Email Form Submission
// Handle Email Form Submission
function handleEmailFormSubmit(e) {
    e.preventDefault();

    const name = document.getElementById("regName").value;
    const email = document.getElementById("regEmail").value;
    const phone = document.getElementById("regPhone").value || "Not Provided";
    const type = document.getElementById("regType").value;
    const progress = document.getElementById("regProgress").value;
    const message = document.getElementById("regMessage").value;
    const feedbackEl = document.getElementById("formSubmissionFeedback");
    const submitBtn = document.getElementById("emailFormSubmitBtn");

    if (!feedbackEl) return;

    // Disable submit button & show loading state
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `Sending... <span class="spinner"></span>`;
    }

    // Check if Web3Forms key is configured
    if (CONFIG.web3formsAccessKey && CONFIG.web3formsAccessKey !== "YOUR_ACCESS_KEY_HERE") {
        feedbackEl.className = "form-feedback-message show";
        feedbackEl.textContent = "Submitting feedback...";
        feedbackEl.style.color = "var(--text-secondary)";

        // Prepare payload for Web3Forms API
        const payload = {
            access_key: CONFIG.web3formsAccessKey,
            name: name,
            email: email,
            phone: phone,
            subject: `New BigFix Lifecycle Training Form: ${type} from ${name}`,
            from_name: "BigFix Training Dashboard",
            request_type: type,
            course_progress: progress,
            message: message
        };

        fetch("https://api.web3forms.com/submit", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(payload)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    feedbackEl.className = "form-feedback-message show success";
                    feedbackEl.innerHTML = "<strong>Success!</strong> Your feedback has been submitted directly. A notification has been sent to your Gmail.";
                    e.target.reset();
                    updateOverallProgress(); // Re-populate progress field
                } else {
                    throw new Error(data.message || "Submission failed");
                }
            })
            .catch(error => {
                console.error("Submission error:", error);
                feedbackEl.className = "form-feedback-message show error";
                feedbackEl.innerHTML = `<strong>Error!</strong> Submission failed: ${error.message}. Please verify your Access Key.`;
            })
            .finally(() => {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = `Send Message <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>`;
                }
            });
    } else {
        // Fallback or warning
        feedbackEl.className = "form-feedback-message show error";
        feedbackEl.innerHTML = "<strong>Submission Error:</strong> Direct submission is not configured yet. <br>Please open <code>app.js</code> and add your free <strong>Web3Forms Access Key</strong> in line 10 to receive Gmail notifications directly!";

        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `Send Message <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>`;
        }
    }
}

// Start Application on Page Load
window.addEventListener("DOMContentLoaded", init);
